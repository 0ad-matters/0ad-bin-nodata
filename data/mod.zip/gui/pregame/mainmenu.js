function init()
{
	Engine.SwitchGuiPage("page_modmod.xml", {
		"cancelbutton": false
	});
}
